e1='info';
e2='brainhouse-gmbh';
e3='de';
e=e1+'&#64;'+e2+'&#46;'+e3;
a1='<a href="mai' + 'lto:';
a2='">';
a3='</a>';
document.write(a1+e+a2+e+a3);